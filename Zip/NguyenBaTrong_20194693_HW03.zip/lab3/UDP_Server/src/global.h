// globals.h
#ifndef GLOBALS_H
#define GLOBALS_H

#define STRING_LENGTH 1024

#endif
