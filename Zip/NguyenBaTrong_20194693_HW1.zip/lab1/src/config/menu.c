#include "menu.h"

void menu() {
    printf("\n ------------------------------------------------------------------\n");
    printf("Menu:\n");
    printf("1. Log in\n");
    printf("2. Post message\n");
    printf("3. Logout\n");
    printf("4. Exit\n");
    printf("------------------------------------------------------------------\n");
};
