#include "global.h"

char currentUser[STRING_LENGTH] = "\0";