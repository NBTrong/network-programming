#include "global.h"

char full_directory[STRING_LENGTH] = "\0";